# 12-Agent Parallel Swarm for Bead Processing

Spin up 12 parallel agents that each claim a P0 bead and execute:
```
rust-contract → implement → qa-enforcer → red-queen
                      ↑              ↓
                      └── FAIL: feedback ──┘
```

## Quick Start

### 1. Start PostgreSQL

```bash
# Option A: System PostgreSQL
sudo systemctl start postgresql
sudo -u postgres createuser -s $USER
createdb swarm_db

# Option B: Docker (recommended for isolation)
docker run -d \
  --name shitty-swarm-manager-db \
  -p 5432:5432 \
  -e POSTGRES_USER=shitty_swarm_manager \
  -e POSTGRES_PASSWORD=shitty_swarm_manager \
  -e POSTGRES_DB=shitty_swarm_manager_db \
  postgres:16
```

### 2. Initialize Database

```bash
swarm init-db

# Or use the helper script (starts container, loads schema, seeds agents)
./.agents/init_postgres_swarm.sh

# Optional: target a specific connection/schema
swarm init-db \
  --url postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5432/shitty_swarm_manager_db \
  --schema crates/swarm-coordinator/schema.sql \
  --seed-agents 12
```

This creates:
- `bead_backlog` (pending/in_progress/completed/blocked queue)
- `bead_claims` (current claim owner + claim status)
- `agent_state` (agent lifecycle + retries + feedback)
- `stage_history` (per-stage execution history)
- `stage_artifacts` (typed artifact storage per stage run)
- `agent_messages` (message passing between stages/agents)
- Monitoring and artifact/message views (`v_active_agents`, `v_swarm_progress`, `v_feedback_required`, `v_bead_artifacts`, `v_unread_messages`)

### 3. Ensure Backlog Beads Exist

```bash
# Check available P0 backlog rows in Postgres
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
SELECT bead_id, status, priority, created_at
FROM bead_backlog
WHERE status = 'pending' AND priority = 'p0'
ORDER BY created_at
LIMIT 12;
"

# Seed test backlog rows if empty
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
INSERT INTO bead_backlog (bead_id, priority, status)
VALUES ('test-1', 'p0', 'pending'), ('test-2', 'p0', 'pending'), ('test-3', 'p0', 'pending')
ON CONFLICT (bead_id) DO NOTHING;
"
```

### 4. Launch the Swarm

Single-agent smoke check first:

```bash
swarm smoke --id 1
```

**From Claude Code**, spawn 12 agents in parallel:

```python
# For each agent 1-12:
Task(
    description="Agent N processing bead",
    prompt="./.agents/agent_N.md",
    subagent_type="general-purpose",
    run_in_background=True
)
```

Or use the prepared launcher:
```bash
swarm spawn-prompts --count 12
# Uses .agents/agent_prompt.md and writes .agents/generated/agent_01.md ... agent_12.md
```

## Monitoring

### Check Active Agents

```bash
swarm monitor --view active

# Script form
./.agents/monitor.sh
```

### Check Progress

```bash
swarm monitor --view progress

# Script form
./.agents/progress.sh
```

### View Failures Requiring Feedback

```bash
swarm monitor --view failures

# Script form
./.agents/failures.sh
```

### View Unread Inter-Agent Messages

```bash
swarm monitor --view messages

# Script form
./.agents/messages.sh
```

### Get Specific Agent State

```sql
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
SELECT
    agent_id,
    bead_id,
    current_stage,
    status,
    implementation_attempt,
    feedback
FROM agent_state
WHERE agent_id = 1;
"
```

### View Stage History for a Bead

```sql
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
SELECT
    stage,
    attempt_number,
    status,
    feedback,
    started_at,
    completed_at
FROM stage_history
WHERE bead_id = 'your-bead-id'
ORDER BY started_at;
"
```

### DB Sanity Check (end-to-end)

After a smoke run:

```bash
swarm smoke --id 1
```

Run these checks to verify claims, stage history, artifacts, and messages:

```sql
-- 1) Agent and claim state
SELECT agent_id, bead_id, current_stage, status, implementation_attempt
FROM agent_state
WHERE agent_id = 1;

SELECT bead_id, claimed_by, status, claimed_at
FROM bead_claims
ORDER BY claimed_at DESC
LIMIT 5;

-- 2) Stage history for recent bead(s)
SELECT bead_id, stage, attempt_number, status, started_at, completed_at
FROM stage_history
ORDER BY started_at DESC
LIMIT 20;

-- 3) Stored stage artifacts
SELECT bead_id, stage, artifact_type, LENGTH(content) AS bytes, created_at
FROM v_bead_artifacts
ORDER BY created_at DESC
LIMIT 30;

-- 4) Unread inter-agent messages
SELECT id, from_agent_id, to_agent_id, bead_id, message_type, subject, created_at
FROM v_unread_messages
ORDER BY created_at DESC
LIMIT 20;
```

Expected outcomes:
- `stage_history` has one row per executed stage attempt.
- `v_bead_artifacts` contains at least `stage_log` plus stage-specific artifacts.
- `v_unread_messages` shows coordination messages (`contract_ready`, `implementation_ready`, etc.) until read.
- `agent_state` and `bead_claims` reflect the latest stage/ownership transitions.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     PostgreSQL Database                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ bead_claims  │  │ agent_state  │  │  stage_history       │  │
│  │ (12 beads)   │  │ (12 agents)  │  │  (audit log)         │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
          ▲                    ▲                      ▲
          │                    │                      │
          └────────────────────┴──────────────────────┘
                            │
          ┌─────────────────┴─────────────────┐
          │                                   │
     ┌────▼────┐  ┌────▼────┐      ┌────▼────┐
     │ Agent 1 │  │ Agent 2 │  ...  │Agent 12 │
     └────┬────┘  └────┬────┘      └────┬────┘
          │            │                 │
          └────────────┴─────────────────┘
                     │
          ┌──────────▼──────────┐
          │   Skills (in order) │
          │                     │
          │ 1. rust-contract    │
          │ 2. functional-rust  │
          │ 3. qa-enforcer      │
          │ 4. red-queen        │
          └─────────────────────┘
```

## Agent Workflow

Each agent:

1. **Claims a bead** (transactional, no two agents claim the same bead)
2. **Spawns zjj workspace** (`zjj add agent-N-{bead_id}`)
3. **Runs rust-contract** → creates contract document
4. **Runs implement** → creates functional Rust code
5. **Runs qa-enforcer** → executes tests
   - If fail → loop back to step 4 with feedback
6. **Runs red-queen** → adversarial QA
   - If fail → loop back to step 4 with feedback
7. **On success** → commits, pushes, marks bead complete, `zjj done`

## Failure Handling

- **Max 3 implementation attempts** per bead
- After 3 failed attempts, bead marked as `blocked`
- Feedback logged to `stage_history` table
- Agent moves to next available bead (if any)

## PostgreSQL Schema

Key tables:
- `bead_backlog`: queue of beads eligible for claiming
- `bead_claims`: bead_id, claimed_by, claimed_at, status
- `agent_state`: agent_id, bead_id, current_stage, status, implementation_attempt, feedback
- `stage_history`: agent_id, bead_id, stage, attempt_number, status, feedback, timestamps
- `stage_artifacts`: stage_history_id, artifact_type, content, metadata, content_hash
- `agent_messages`: from/to agent routing, message_type, subject/body, read status
- `swarm_config`: max_agents=12, max_implementation_attempts=3, claim_label=p0

Core DB functions:
- `claim_next_p0_bead(agent_id)`
- `store_stage_artifact(stage_history_id, artifact_type, content, metadata)`
- `send_agent_message(from_repo_id, from_agent_id, to_repo_id, to_agent_id, bead_id, message_type, subject, body, metadata)`
- `get_unread_messages(repo_id, agent_id, bead_id)`
- `mark_messages_read(repo_id, agent_id, message_ids)`

## Configuration

```bash
# Runtime DB URL (used by swarm commands)
DATABASE_URL=postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5432/shitty_swarm_manager_db

# Optional: dedicated test DB URL for ignored DB integration tests
SWARM_TEST_DATABASE_URL=postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5432/shitty_swarm_manager_test_db
```

Or set `.swarm/config.toml`:

```toml
database_url = "postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5432/shitty_swarm_manager_db"
rust_contract_cmd = "br show {bead_id}"
implement_cmd = "jj status"
qa_enforcer_cmd = "moon run :quick"
red_queen_cmd = "moon run :test"
```

CLI DB override options (available on all commands):

```bash
# Explicit URL override
swarm status --database-url "postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5437/shitty_swarm_manager_db"

# Pull URL from pass entry (expects connection_url: ... or first line postgres URL)
swarm status --database-url-pass infra/shitty-swarm-manager/postgres
swarm init-db --database-url-pass infra/shitty-swarm-manager/postgres
```

## Troubleshooting

### Database connection failed
```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432

# Check database exists
psql -h localhost -U shitty_swarm_manager -d postgres -c "\l" | grep shitty_swarm_manager_db

# Recreate schema if needed
swarm init-db --url postgresql://shitty_swarm_manager:shitty_swarm_manager@localhost:5432/shitty_swarm_manager_db
```

### No beads available
```bash
# Check Postgres backlog has pending p0 beads
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
SELECT COUNT(*)
FROM bead_backlog
WHERE status = 'pending' AND priority = 'p0';
"

# Add test beads if needed
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
INSERT INTO bead_backlog (bead_id, priority, status)
SELECT format('test-%s', g), 'p0', 'pending'
FROM generate_series(1, 12) AS g
ON CONFLICT (bead_id) DO NOTHING;
"
```

### Agent stuck in error state
```sql
-- Reset agent to idle
UPDATE agent_state
SET status = 'idle',
    bead_id = NULL,
    current_stage = NULL,
    feedback = NULL,
    implementation_attempt = 0,
    last_update = NOW()
WHERE agent_id = <agent_id>;

-- Release bead claim
UPDATE bead_claims
SET status = 'blocked'
WHERE bead_id = '<bead_id>';
```

## Cleanup

```bash
# Stop agents (Ctrl+C or kill Task processes)

# Drop database
psql -h localhost -U shitty_swarm_manager -d postgres -c "DROP DATABASE IF EXISTS shitty_swarm_manager_db;"

# Or reset for next run
psql -h localhost -U shitty_swarm_manager -d shitty_swarm_manager_db -c "
TRUNCATE agent_messages, stage_artifacts, stage_history, bead_claims, bead_backlog RESTART IDENTITY;
UPDATE agent_state
SET bead_id = NULL,
    current_stage = NULL,
    stage_started_at = NULL,
    status = 'idle',
    feedback = NULL,
    implementation_attempt = 0,
    last_update = NOW();
"

# Clean up workspaces
zjj status  # List workspaces
# Manually remove completed workspaces
```
